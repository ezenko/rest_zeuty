INSERT INTO [db_prefix]country_spr VALUES (22,'Bassas da India',0)
