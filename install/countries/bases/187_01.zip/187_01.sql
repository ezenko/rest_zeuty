INSERT INTO [db_prefix]country_spr VALUES (187,'Palmyra Atoll',0)
