INSERT INTO [db_prefix]country_spr VALUES (34,'British Indian Ocean Territory',0)
