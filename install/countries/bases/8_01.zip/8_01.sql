INSERT INTO [db_prefix]country_spr VALUES (8,'Antarctica',0)
