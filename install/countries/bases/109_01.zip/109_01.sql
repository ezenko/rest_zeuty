INSERT INTO [db_prefix]country_spr VALUES (109,'Howland Island',0)
