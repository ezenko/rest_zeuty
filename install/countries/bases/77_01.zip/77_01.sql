INSERT INTO [db_prefix]country_spr VALUES (77,'Europa Island',0)
