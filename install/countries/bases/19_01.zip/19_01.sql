INSERT INTO [db_prefix]country_spr VALUES (19,'Baker Island',0)
