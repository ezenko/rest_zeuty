INSERT INTO [db_prefix]country_spr VALUES (123,'Jarvis Island',0)
INSERT INTO [db_prefix]region_spr VALUES (7600,123,'No region')
INSERT INTO [db_prefix]city_spr VALUES (817676,123,'Millersville','','',7600,-0.3797200,-160.0188900)
