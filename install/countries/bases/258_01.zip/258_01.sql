INSERT INTO [db_prefix]country_spr VALUES (258,'Wake Island',0)
