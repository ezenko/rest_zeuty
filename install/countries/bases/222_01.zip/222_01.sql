INSERT INTO [db_prefix]country_spr VALUES (222,'South Georgia and the South Sandwich Islands',0)
INSERT INTO [db_prefix]region_spr VALUES (7638,222,'No region')
INSERT INTO [db_prefix]city_spr VALUES (1445815,222,'Grytviken','','',7638,-54.2766667,-36.5116666)
INSERT INTO [db_prefix]city_spr VALUES (1445816,222,'Stromness','','',7638,-54.1561110,-36.7161110)
