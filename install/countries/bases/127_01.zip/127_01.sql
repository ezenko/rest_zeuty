INSERT INTO [db_prefix]country_spr VALUES (127,'Juan de Nova Island',0)
