INSERT INTO [db_prefix]country_spr VALUES (58,'Coral Sea Islands',0)
