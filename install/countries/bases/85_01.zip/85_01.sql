INSERT INTO [db_prefix]country_spr VALUES (85,'French Southern and Antarctic Lands',0)
INSERT INTO [db_prefix]region_spr VALUES (7579,85,'No region')
INSERT INTO [db_prefix]city_spr VALUES (506292,85,'Port-aux-Francais','','',7579,-49.3500000,70.2166667)
