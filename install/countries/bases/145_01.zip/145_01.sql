INSERT INTO [db_prefix]country_spr VALUES (145,'Macau',0)
