INSERT INTO [db_prefix]country_spr VALUES (238,'Tokelau',0)
INSERT INTO [db_prefix]region_spr VALUES (7646,238,'No region')
INSERT INTO [db_prefix]city_spr VALUES (1573919,238,'Fakaofu Village','','',7646,-9.3833333,-171.2500000)
