INSERT INTO [db_prefix]country_spr VALUES (194,'Pitcairn Islands',0)
INSERT INTO [db_prefix]region_spr VALUES (7625,194,'No region')
INSERT INTO [db_prefix]city_spr VALUES (1211199,194,'Adamstown','','',7625,-25.0666666,-130.0833332)
