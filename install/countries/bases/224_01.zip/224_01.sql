INSERT INTO [db_prefix]country_spr VALUES (224,'Spratly Islands',0)
INSERT INTO [db_prefix]region_spr VALUES (7639,224,'No region')
INSERT INTO [db_prefix]city_spr VALUES (1471560,224,'Kalayaan Islands','','',7639,10.0000000,118.7500000)
