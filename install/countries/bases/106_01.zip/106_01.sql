INSERT INTO [db_prefix]country_spr VALUES (106,'Holy See (Vatican City)',0)
