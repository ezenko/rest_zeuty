INSERT INTO [db_prefix]country_spr VALUES (125,'Johnston Atoll',0)
