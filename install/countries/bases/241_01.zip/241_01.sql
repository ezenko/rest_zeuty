INSERT INTO [db_prefix]country_spr VALUES (241,'Tromelin Island',0)
