INSERT INTO [db_prefix]country_spr VALUES (52,'Cocos (Keeling) Islands',0)
INSERT INTO [db_prefix]region_spr VALUES (7568,52,'No region')
INSERT INTO [db_prefix]city_spr VALUES (307754,52,'Bantam Village','','',7568,-12.1166667,96.8833333)
