INSERT INTO [db_prefix]country_spr VALUES (170,'Navassa Island',0)
