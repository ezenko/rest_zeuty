INSERT INTO [db_prefix]country_spr VALUES (190,'Paracel Islands',0)
