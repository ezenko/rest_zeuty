INSERT INTO [db_prefix]country_spr VALUES (121,'Jan Mayen',0)
